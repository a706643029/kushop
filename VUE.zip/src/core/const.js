export default {
    EVENT_USER_LOGIN: 'event_user_login', // 用户登录事件
    EVENT_USER_REGISTER: 'event_user_register', // 用户注册事件
    EVENT_VIDEO_END: 'event_video_end', // 视频播放结束事件
    EVENT_POPUP: 'popUpEvent', // 弹窗广告弹出事件
}
